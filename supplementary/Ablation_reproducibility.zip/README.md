# Four-route same-input ablation

The archive retains 16 frozen public inputs, all 192 timed-run records,
all completed arrays, 30-second censored runs, whole-process peak resident
memory, operation counters, pruning traces and exact reference lists.
The methods share reduction, real-root isolation and final support checks.
Only propagation and the energy combiner vary. Unsupported propagation
falls back to the same unpruned combiner. No factor budget is imposed.

Install/use Python with SymPy 1.14.0. To check the saved results without
remeasuring timings:

```text
python tools/replay_ablation.py .
```

To repeat the timings on Linux/WSL, use a fresh output folder:

```text
python3 tools/reproduce_ablation.py . ../new_ablation_run
python3 ../new_ablation_run/tools/replay_ablation.py ../new_ablation_run
```

The runner excludes common imports and child startup and records them
separately. It includes public IO, all reconstruction work and serialization.
Its single-CPU affinity, method order and 30-second after-ready censor are
fixed by protocol.json. Memory is the child peak resident set including
interpreter/import memory; censored peaks are read before termination.

The archive's checks use rational arithmetic and the same SymPy backend
as the solvers. Reference equality and deletion-trace replay are not
formal verification or an independent algebra system. Replaying saved
timings does not reproduce their measurement. Reused synthetic inputs
are explicitly identified; they are not a new held-out cohort.
