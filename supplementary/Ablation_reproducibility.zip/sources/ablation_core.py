"""Four complete-list routes with identical public reduction and root isolation.

Only propagation and the final energy combiner vary. Decision traces are not
stored for any route; complete arrays, stage counters and pruning traces are.
"""
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import product
from math import prod
from time import perf_counter
import sympy as s
import exact_cactus_decoder as cd
from cubic_probability_decoder import Quad,real_roots,radical_sign
from coordinate_decoder import coordinates,propagate

METHODS=['enumerate','mitm','prop_enumerate','prop_mitm']

def prepare(public):
    started=perf_counter(); p=cd.canonical_public(public)
    m,n,edges=p['m'],p['n'],p['edges'];u,v,gu,gv=(p[k] for k in ['u','v','gu','gv'])
    cycles=cd.cycle_basis(m,n,edges)
    weights=[u[i]*v[j] for i,j in edges]
    rhs=[-u[i]*gu[i] for i in range(m)]+[-v[j]*gv[j] for j in range(n)]
    for e,(i,j) in enumerate(edges): rhs[i]+=weights[e]**2;rhs[m+j]+=weights[e]**2
    base=cd.forest_base(m,n,edges,cycles,rhs)
    data=dict(p=p,cycles=cycles,weights=weights,base=base)
    if base is None:return dict(data,early='Empty',reason='inconsistent_margins',preparation_seconds=perf_counter()-started)
    norm=2*p['loss']+sum(w*w for w in weights)-sum(a*b for a,b in zip(u,gu))-sum(a*b for a,b in zip(v,gv))
    t=s.Symbol('t');polys=[]
    for cycle in cycles:
        z=[base[e]+(-1)**j*t for j,e in enumerate(cycle)]
        polys.append(s.Poly(s.prod(z[::2])-s.prod(z[1::2]),t,domain=s.QQ))
    if any(not f.is_zero and f.degree()==0 for f in polys):return dict(data,early='Empty',reason='nonzero_constant_cycle',preparation_seconds=perf_counter()-started)
    if any(f.is_zero for f in polys):return dict(data,early='Degenerate',reason='identically_zero_cycle',preparation_seconds=perf_counter()-started)
    root_started=perf_counter();roots=[];intervals=[];energy_polys=[];energies=[]
    for cycle,f in zip(cycles,polys):
        rr=f.real_roots(multiple=False,radicals=False)
        ii=f.intervals(eps=s.Rational(1,65536))
        assert len(rr)==len(ii) and all(a[1]==b[1] for a,b in zip(rr,ii))
        rootset=[z for z,_ in rr];roots.append(rootset);intervals.append([ab for ab,_ in ii])
        ep=s.Poly(sum(((base[e]+(-1)**j*t)/weights[e])**2 for j,e in enumerate(cycle)),t)
        energy_polys.append(ep)
        energies.append([ep.eval(z) if z.is_Rational else ep.rem(s.Poly(z.poly.as_expr().subs(z.poly.gen,t),t)).eval(z) for z in rootset])
    covered={e for cyc in cycles for e in cyc}
    fixed=sum((base[e]/weights[e])**2 for e in range(len(edges)) if e not in covered)
    return dict(data,polys=polys,roots=roots,intervals=intervals,energy_polys=energy_polys,energies=energies,norm=norm,required=norm-fixed,
                root_seconds=perf_counter()-root_started,preparation_seconds=perf_counter()-started)

def prune(data):
    if any(f.degree()>3 for f in data['polys']):return None,'cycle_degree_above_three'
    groups=[]
    for f,intervals,ep in zip(data['polys'],data['intervals'],data['energy_polys']):
        try: local=real_roots(f)
        except ValueError:return None,'irreducible_factor_above_two'
        ordered=[]
        for lohi in intervals:
            lo,hi=map(Q,lohi)
            # SymPy isolating intervals may share an endpoint with an exact
            # rational root in another interval. Nonpoint intervals are open.
            matches=[q for q in local if
                     (radical_sign(q.a-lo,q.b,q.d)==0 if lo==hi else
                      radical_sign(q.a-lo,q.b,q.d)>0 and radical_sign(q.a-hi,q.b,q.d)<0)]
            assert len(matches)==1
            ordered.append(matches[0])
        assert len(ordered)==len(local)
        ee=[]
        for q in ordered:
            z=Quad()
            for coeff in ep.all_coeffs():z=z*q+Q(coeff)
            ee.append(z)
        groups.append(ee)
    reps,vectors=coordinates(groups); target=[Q(data['required'])]+[Q(0)]*len(reps)
    domains,trace=propagate(vectors,target)
    # Preserve the same replay format as the original necessary-bound rule.
    return dict(domains=domains,trace=trace,coordinates=len(reps)+1,
                deletions=sum(map(len,trace)),passes=len(trace),
                vectors=[[[str(q) for q in vec] for vec in group] for group in vectors],
                target=list(map(str,target))),None

def decode(public,method):
    assert method in METHODS
    started=perf_counter();data=prepare(public)
    counters=dict(energy_tests=0,full_tuples_visited=0,actual_support_tests=0,join_comparisons=0,
                  partial_sums_generated=0,exact_predicate_calls=0,propagation_deletions=0,propagation_passes=0)
    out=dict(method=method,candidate_class='all actual real targets; no factor budget',complete=True,candidates=[],counters=counters,
             phases=dict(common_preparation=data['preparation_seconds'],coordinate_propagation=0.0,energy_combination=0.0,final_support=0.0))
    if 'early' in data:return dict(out,status=data['early'],complete=data['early']!='Degenerate',reason=data['reason'])
    domains=[list(range(len(rr))) for rr in data['roots']]
    out['tuple_product_before']=prod(map(len,domains))
    out['cycle_root_counts']=list(map(len,domains))
    out['propagation_requested']=method.startswith('prop_')
    if out['propagation_requested']:
        tic=perf_counter();pruned,reason=prune(data)
        out['phases']['coordinate_propagation']=perf_counter()-tic
        out['propagation_applicable']=pruned is not None
        if pruned is None:out['propagation_fallback_reason']=reason
        else:
            domains=pruned['domains'];out['propagation_certificate']=pruned
            counters['propagation_deletions']=pruned['deletions'];counters['propagation_passes']=pruned['passes']
    else:out['propagation_applicable']=None
    out['tuple_product_after']=prod(map(len,domains))
    original_sign=cd.exact_sign
    def sign(expr):counters['exact_predicate_calls']+=1;return original_sign(expr)
    cd.exact_sign=sign
    try:
        tic=perf_counter()
        if any(not dom for dom in domains): choices=[]
        elif method.endswith('mitm'):
            groups=[[data['energies'][i][j] for j in dom] for i,dom in enumerate(domains)]
            local,stats=cd.energy_choices(groups,data['required'])
            choices=[tuple(domains[i][j] for i,j in enumerate(choice)) for choice in local]
            counters['join_comparisons']=stats['exact_comparisons']
            counters['partial_sums_generated']=sum(stats['partial_sizes'])
            out['join']=stats
        else: choices=product(*domains)
        matches=[]
        for choice in choices:
            counters['full_tuples_visited']+=1;counters['energy_tests']+=1
            gap=sum(data['energies'][i][j] for i,j in enumerate(choice))-data['required']
            if sign(gap)==0:matches.append(choice)
        out['phases']['energy_combination']=perf_counter()-tic
        tic=perf_counter();p=data['p'];weights=data['weights'];base=data['base']
        for choice in matches:
            values=[base[e]/weights[e] for e in range(len(p['edges']))]
            for cycle,rr,j in zip(data['cycles'],data['roots'],choice):
                for k,e in enumerate(cycle):values[e]+=(-1)**k*rr[j]/weights[e]
            counters['actual_support_tests']+=1
            actual,_=cd.actual_budget(p['m'],p['n'],p['edges'],values,False)
            if actual:out['candidates'].append(dict(values=list(map(str,values)),roots=list(choice)))
        out['phases']['final_support']=perf_counter()-tic
    finally:cd.exact_sign=original_sign
    out.update(status='Empty' if not out['candidates'] else 'Unique' if len(out['candidates'])==1 else 'Ambiguous',decode_seconds=perf_counter()-started)
    return out
