"""Verify retained outputs and generate tables; never rerun benchmark timers."""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
from statistics import median
import hashlib,json,sys

HERE=Path(__file__).resolve().parent;RUN=HERE/'ablation';SRC=HERE/'manuscript'
sys.path.insert(0,str(RUN/'sources'))
import sympy as s
from exact_cactus_decoder import canonical_public,exact_sign,actual_budget
METHODS=['enumerate','mitm','prop_enumerate','prop_mitm']
LABELS={'enumerate':'Enumeration','mitm':'MITM','prop_enumerate':'Propagation + enumeration','prop_mitm':'Propagation + MITM'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')

def same(first,second):
    if len(first)!=len(second):return False
    remaining=[list(map(s.sympify,row)) for row in second]
    for row in first:
        values=list(map(s.sympify,row))
        for i,other in enumerate(remaining):
            if len(values)==len(other) and all(exact_sign(s.expand(a-b))==0 for a,b in zip(values,other)):
                remaining.pop(i);break
        else:return False
    return not remaining

def direct(public,arrays):
    p=canonical_public(public)
    for row in arrays:
        values=list(map(s.sympify,row));gu=[s.S.Zero]*p['m'];gv=[s.S.Zero]*p['n'];loss=s.S.Zero
        assert len(values)==len(p['edges'])
        for (i,j),c in zip(p['edges'],values):
            residual=p['u'][i]*p['v'][j]-c
            gu[i]+=residual*p['v'][j];gv[j]+=residual*p['u'][i];loss+=residual**2/2
        assert all(exact_sign(s.expand(a-b))==0 for a,b in zip(gu+gv+[loss],p['gu']+p['gv']+[p['loss']]))
        assert actual_budget(p['m'],p['n'],p['edges'],values,False)[0]

def replay_pruning(cert):
    vectors=[[[Q(z) for z in vec] for vec in group] for group in cert['vectors']]
    target=list(map(Q,cert['target']));domains=[list(range(len(group))) for group in vectors]
    for cuts in cert['trace']:
        removed=set()
        for cut in cuts:
            i,j,k=(cut[z] for z in ['cycle','branch','coordinate'])
            assert j in domains[i] and (i,j) not in removed
            need=target[k]-vectors[i][j][k]
            lo=sum(min(vectors[a][b][k] for b in domains[a]) for a in range(len(domains)) if a!=i)
            hi=sum(max(vectors[a][b][k] for b in domains[a]) for a in range(len(domains)) if a!=i)
            assert (need,lo,hi)==tuple(Q(cut[z]) for z in ['need','lower','upper'])
            assert need<lo or need>hi;removed.add((i,j))
        domains=[[j for j in dom if (i,j) not in removed] for i,dom in enumerate(domains)]
    assert domains==cert['domains']

def run():
    protocol=read(RUN/'protocol.json');raw=read(RUN/'results.json')
    assert raw['complete'] and len(raw['records'])==protocol['jobs']==192
    assert raw['protocol_sha256']==sha(RUN/'protocol.json')
    assert protocol['runner_sha256']==sha(HERE/'run_ablation.py')
    for folder,key in [('sources','source_hashes'),('public','public_hashes'),('references','reference_hashes')]:
        assert all(sha(RUN/folder/name)==d for name,d in protocol[key].items())
    seen=set();outputs={};array_checks=trace_checks=0
    for rec in raw['records']:
        key=(rec['id'],rec['method'],rec['repeat']);assert key not in seen;seen.add(key)
        assert rec['outcome'] in ['complete','timeout'],rec
        assert rec.get('peak_rss_kib',0)>0
        if rec['outcome']=='timeout':assert rec['censor_seconds']==30;continue
        outpath=RUN/'outputs'/f'{key[0]}--{key[1]}--{key[2]}.json';assert sha(outpath)==rec['output_sha256']
        out=read(outpath);assert out['complete'] and out['method']==key[1]
        arrays=[c['values'] for c in out['candidates']]
        reference=read(RUN/'references'/(key[0]+'.json'))
        assert same(arrays,[c['values'] for c in reference['candidates']]),key
        direct(read(RUN/'public'/(key[0]+'.json')),arrays);array_checks+=len(arrays)
        if 'propagation_certificate' in out:replay_pruning(out['propagation_certificate']);trace_checks+=1
        outputs[key]=out
    details=[];counts={method:dict(Counter(r['outcome'] for r in raw['records'] if r['method']==method)) for method in METHODS}
    for number,case in enumerate(protocol['cases'],1):
        row={'number':number,'id':case['id'],'methods':{}}
        for method in METHODS:
            rr=[r for r in raw['records'] if r['id']==case['id'] and r['method']==method];assert len(rr)==3
            done=[r for r in rr if r['outcome']=='complete']
            d=dict(completed=len(done),seconds=[r.get('seconds') for r in rr],peak_rss_kib=[r['peak_rss_kib'] for r in rr],
                   median_seconds=median(r['seconds'] for r in done) if len(done)==3 else None,
                   median_peak_mib=median(r['peak_rss_kib'] for r in rr)/1024)
            if done:
                oo=[outputs[(case['id'],method,r['repeat'])] for r in done]
                assert all(o['counters']==oo[0]['counters'] for o in oo)
                d.update(counters=oo[0]['counters'],tuples_before=oo[0].get('tuple_product_before'),tuples_after=oo[0].get('tuple_product_after'),
                         propagation_applicable=oo[0]['propagation_applicable'],propagation_fallback_reason=oo[0].get('propagation_fallback_reason'),
                         arrays=len(oo[0]['candidates']),status=oo[0]['status'])
            row['methods'][method]=d
        details.append(row)
    runtime=read(RUN/'runtime.json');summary=dict(method_counts=counts,per_input=details,runtime=runtime,
        completed_list_reference_checks=len(outputs),direct_array_reply_and_support_checks=array_checks,pruning_trace_replays=trace_checks,
        new_timing_runs=192,reference_scope='same frozen complete-list references; shared SymPy arithmetic backend; no claim of new independent solver',
        censored_times_not_substituted=True)
    dump(RUN/'validation.json',dict(status='PASS',**summary))

    # Main table: largest all-six-cycle input in the pre-existing fourteen-input
    # cohort. The supplement retains all sixteen cases, including fallbacks.
    example=details[6];assert example['id']=='validation-07-flower-r12-k333333333333'
    lines=[r'\begin{table}[htbp]\centering\small',r'\begin{tabular}{lrrrr}\toprule',
           r'Route & Complete/48 & Tuples & Seconds & MiB\\\midrule']
    for method in METHODS:
        d=example['methods'][method];tt=f"{d['median_seconds']:.3f}" if d['median_seconds'] is not None else f"{d['completed']}/3; TO"
        lines.append(f"{LABELS[method]} & {counts[method].get('complete',0)} & {d.get('tuples_after','--')} & {tt} & {d['median_peak_mib']:.1f}"+r' \\')
    lines += [r'\bottomrule\end{tabular}',r'\caption{Four-route ablation. Completion counts cover all sixteen inputs and three repetitions. The last three columns concern input 7, the largest all-six-cycle flower in the original comparison: surviving root-tuple product, median end-to-end seconds, and median whole-process peak resident memory. All cases and censoring are retained in the supplement.}\label{tab:ablation-main}',r'\end{table}']
    table='\n'.join(lines)+'\n'
    text=r'''\subsection{Ablating propagation and the energy combiner}\label{sec:ablation}
We use a $2\times2$ design: coordinate propagation on or off, followed
by direct enumeration or exact meet-in-the-middle. All four routes use
the same public reduction, real-root isolation, energy predicates and
final support checks, and return complete actual real lists. A pruning
failure to decide uniqueness is followed by the chosen combiner;
inputs outside Proposition~\ref{prop:squareclass} retain their original
domains. The cohort contains the preceding fourteen public inputs and
two existing empty-list controls, with three serial runs per route.
The thirty-second after-ready limit includes public IO and output
serialization. Each run is a fresh single-CPU Linux/WSL child.

'''+table
    d0=example['methods']['enumerate'];dm=example['methods']['mitm'];dp=example['methods']['prop_mitm']
    text+=f'''On input 7, propagation reduces the root product from
${d0['tuples_before']}$ to ${dp['tuples_after']}$ before either combiner.
Without propagation, MITM generates
${dm['counters']['partial_sums_generated']}$ partial sums and uses
${dm['counters']['join_comparisons']}$ exact energy comparisons;
direct enumeration tests all ${d0['counters']['energy_tests']}$ tuples.
These separate effects explain the saved combination work.
Four higher-degree inputs use the unpruned fallback. Their outcomes,
the two ambiguous controls and both empty-list controls are retained.
Every completed list agrees with its frozen exact reference and
reproduces the original reply. Supplementary
Section~\\ref{{app:ablation}} reports every input, peak memory and
operation counter under this protocol.
'''
    (SRC/'ablation_summary.tex').write_text(text,encoding='utf-8')

    intro=r'''\section{Four-route same-input ablation}\label{app:ablation}
The sixteen public inputs are frozen before the timed experiment.
Inputs 1--14 have the same public-file hashes as the unified comparison;
15 and 16 are the existing lattice controls \texttt{empty\_r1} and
\texttt{empty\_r4}. These are reused synthetic inputs, not a new holdout.
The four routes share one reduction and exact root-isolation routine.
Propagation is applied only when all cycle degrees are at most three
and their irreducible factors have degree at most two; otherwise the
whole input falls back to the unpruned combiner. An unresolved propagated
domain is passed to enumeration or MITM, so all routes have the same
complete-list output contract and impose no factor budget.

Each measured run uses a fresh fork child after common imports,
SymPy 1.14.0 and Python 3.12.3 on Linux/WSL, AMD Ryzen 7 5800U,
with affinity fixed to one available CPU. Method order rotates across
the three repetitions. Public reading, reduction, root work, optional
propagation, energy matching, support tests and output serialization
are included. Common imports and child startup are separately logged.
No per-tuple decision trace is retained by any route; all complete
arrays, operation counters and propagation deletion traces are saved.
No Cartesian-product prebudget is imposed. A run that exceeds thirty
seconds after ready is censored, and no timeout is used as a measured
runtime. These ablation times are not pooled with earlier solver times.

Tables~\ref{tab:ablation-times}--\ref{tab:ablation-operations} retain every
input. Peak memory is Linux \texttt{ru\_maxrss}, including inherited
interpreter and import memory; no baseline is subtracted. For censored
runs, the child high-water resident set is read before termination.
Memory medians use all three recorded peaks. Time medians require all
three runs to complete. Complete-list references are frozen separately
and are not passed to a solver. Every completed output is checked
against that reference and against the original loss, gradients and
actual-support predicates. Deletion inequalities are replayed from
their rational coordinate vectors. These checks share the SymPy
arithmetic backend with the decoders.

'''
    def make_table(label,header,rows,caption,columns):
        return '\n'.join([r'\begin{table}[htbp]\centering\small',r'\begin{tabular}{'+columns+r'}\toprule',header+r'\\\midrule']+rows+[r'\bottomrule\end{tabular}',r'\caption{'+caption+r'}\label{'+label+r'}',r'\end{table}',''])
    rows=[]
    for item in details:
        cells=[]
        for method in METHODS:
            d=item['methods'][method];cells.append(f"{d['median_seconds']:.3f}" if d['median_seconds'] is not None else f"{d['completed']}/3; TO")
        rows.append(str(item['number'])+' & '+' & '.join(cells)+r' \\')
    intro+=make_table('tab:ablation-times','Input & Enum. & MITM & Prop.+enum. & Prop.+MITM',rows,'End-to-end seconds on the sixteen fixed inputs. Input numbering 1--14 matches Table~\\ref{tab:strengthened-times}; TO denotes thirty-second censoring, with the number of completed repetitions shown.','rrrrr')
    rows=[]
    for item in details:
        cells=[f"{item['methods'][m]['median_peak_mib']:.1f}"+('$^\\dagger$' if item['methods'][m]['completed']<3 else '') for m in METHODS]
        rows.append(str(item['number'])+' & '+' & '.join(cells)+r' \\')
    intro+=make_table('tab:ablation-memory','Input & Enum. & MITM & Prop.+enum. & Prop.+MITM',rows,'Whole-process peak resident memory in MiB, median over three repetitions. A dagger marks a route with censored runs; its peaks are retained, without claiming those runs completed.','rrrrr')
    rows=[]
    for item in details:
        d=item['methods'];mitm=d['mitm'];full=d['prop_mitm'];enum=d['enumerate']
        rows.append(' & '.join([str(item['number']),str(mitm.get('tuples_before','--')),str(full.get('tuples_after','--')),
            str(enum['counters']['energy_tests']) if 'counters' in enum else 'TO',
            str(mitm['counters']['partial_sums_generated']) if 'counters' in mitm else 'TO',
            str(mitm['counters']['join_comparisons']) if 'counters' in mitm else 'TO',
            str(full['counters']['join_comparisons']) if 'counters' in full else 'TO'])+r' \\')
    intro+=make_table('tab:ablation-operations',r'Input & $M$ & $M_{\rm prop}$ & Enum. tests & MITM sums & MITM cmp. & Full cmp.',rows,
        r'Exact mechanism counts, identical across completed repetitions. $M$ and $M_{\rm prop}$ are potential tuple products before and after propagation, not elapsed time. Enumeration tests are executed norm comparisons; MITM sums count both generated partial lists, and cmp. counts sorting and matching comparisons. Final energy rechecks, support tests, predicate calls and deletion counts are additionally saved per run. A TO entry does not estimate work after termination.','rrrrrrr')
    intro+=f"The completed-run counts out of 48 are {', '.join(str(counts[m].get('complete',0)) for m in METHODS)} in table-column order. All {len(outputs)} completed lists agree with their references; {array_checks} returned arrays pass direct reply and support checks, and {trace_checks} pruning traces replay.\n"
    (SRC/'ablation_protocol.tex').write_text(intro,encoding='utf-8')
    print(json.dumps({'status':'PASS','counts':counts,'completed_lists_checked':len(outputs),'arrays_checked':array_checks,'pruning_traces':trace_checks},ensure_ascii=True,indent=2))

if __name__=='__main__':run()
