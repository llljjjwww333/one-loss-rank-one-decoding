"""Replay saved ablation outputs, exact references and pruning inequalities."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('folder',type=Path);args=parser.parse_args()
    root=args.folder.resolve();sys.path.insert(0,str(root/'sources'))
    helper_path=(root/'tools/analyze_ablation.py') if (root/'tools/analyze_ablation.py').exists() else Path(__file__).parent/'analyze_ablation.py'
    spec=importlib.util.spec_from_file_location('ablation_replay_helpers',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    def read(name):return json.loads((root/name).read_text(encoding='utf-8'))
    def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
    if (root/'SHA256_manifest.json').exists():
        for name,digest in read('SHA256_manifest.json').items():assert sha(root/name)==digest,name
    protocol=read('protocol.json');results=read('results.json')
    assert results['complete'] and len(results['records'])==protocol['jobs']==192
    assert results['protocol_sha256']==sha(root/'protocol.json')
    for folder,key in [('sources','source_hashes'),('public','public_hashes'),('references','reference_hashes')]:
        for name,digest in protocol[key].items():assert sha(root/folder/name)==digest
    completed=arrays=traces=0;seen=set()
    for rec in results['records']:
        key=(rec['id'],rec['method'],rec['repeat']);assert key not in seen;seen.add(key)
        if rec['outcome']=='timeout':assert rec['censor_seconds']==30;continue
        assert rec['outcome']=='complete',rec
        output=root/'outputs'/f'{key[0]}--{key[1]}--{key[2]}.json';assert sha(output)==rec['output_sha256']
        out=json.loads(output.read_text());assert out['complete']
        vv=[c['values'] for c in out['candidates']];ref=read('references/'+key[0]+'.json')
        assert helper.same(vv,[c['values'] for c in ref['candidates']])
        helper.direct(read('public/'+key[0]+'.json'),vv);arrays+=len(vv)
        if 'propagation_certificate' in out:helper.replay_pruning(out['propagation_certificate']);traces+=1
        completed+=1
    print(json.dumps({'status':'PASS','timed_runs_retained':192,'complete_lists_checked':completed,'direct_reply_and_support_arrays':arrays,'pruning_traces_replayed':traces,'timings_remeasured':False},indent=2))

if __name__=='__main__':main()
