"""Remeasure the frozen cohort into a fresh folder on Linux/WSL."""
from pathlib import Path
import argparse,importlib.util,json,shutil

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('saved_bundle',type=Path);ap.add_argument('new_run',type=Path)
    a=ap.parse_args();saved=a.saved_bundle.resolve();new=a.new_run.resolve()
    assert not new.exists(),'Use a fresh output directory to retain the saved measurements'
    new.mkdir(parents=True)
    for name in ['public','sources','references','tools']:shutil.copytree(saved/name,new/name)
    shutil.copy2(saved/'protocol.json',new/'protocol.json');(new/'outputs').mkdir()
    runner=new/'tools/run_ablation.py';spec=importlib.util.spec_from_file_location('frozen_ablation_runner',runner)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.RUN=new;module.ROOT=new.parent
    module.run()

if __name__=='__main__':main()
