"""Frozen same-input 2x2 ablation; serial Linux/WSL after-ready measurements."""
from pathlib import Path
import hashlib,json,multiprocessing as mp,os,platform,resource,shutil,signal,sys,time

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3];PAPER=HERE.parents[1];RUN=HERE/'ablation'
METHODS=['enumerate','mitm','prop_enumerate','prop_mitm']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

def freeze():
    assert not (RUN/'protocol.json').exists()
    for name in ['public','sources','references','outputs']:(RUN/name).mkdir(parents=True,exist_ok=True)
    old=PAPER/'revisions/20261026_energy_constraints/uniform_linux';protocol=json.loads((old/'protocol.json').read_text())
    cases=[]
    for c in protocol['cases']:
        name=c['id'];src=old/'public'/(name+'.json')
        assert sha(src)==protocol['public_hashes'][name+'.json']
        shutil.copy2(src,RUN/'public'/src.name)
        ref=old/'outputs'/(name+'--cycle_mitm--1.json')
        shutil.copy2(ref,RUN/'references'/(name+'.json'))
        cases.append(dict(id=name,origin='same fourteen public inputs as existing comparison'))
    # Prespecified empty controls are drawn from the existing frozen lattice set.
    for size in [1,4]:
        name=f'empty_r{size}';src=PAPER/'revisions/20261026_energy_constraints/lattice_public'/(name+'.json')
        shutil.copy2(src,RUN/'public'/src.name);cases.append(dict(id=name,origin='existing empty lattice control'))
        dump(RUN/'references'/(name+'.json'),{'complete':True,'status':'Empty','candidates':[]})
    for name in ['exact_cactus_decoder.py','cubic_probability_decoder.py']:shutil.copy2(PAPER/name,RUN/'sources'/name)
    shutil.copy2(PAPER/'energy_constraints_v1/coordinate_decoder.py',RUN/'sources/coordinate_decoder.py')
    shutil.copy2(HERE/'ablation_core.py',RUN/'sources/ablation_core.py')
    dump(RUN/'protocol.json',dict(version=1,status='frozen_before_timed_runs',cases=cases,repeats=3,methods=METHODS,jobs=len(cases)*12,
        seconds_after_ready=30,execution='serial fresh fork child; one available CPU; method order rotates',
        candidate_class='all actual real targets; no factor budget',
        factor_design='same common reduction and exact root isolation; propagation on/off x enumeration/MITM',
        unsupported_propagation='fall back to same unpruned combiner, retaining the input',
        includes='public JSON reading, common preparation, pruning if requested, energy combiner, actualness, complete-array serialization',
        excludes='common parent imports and fresh-child startup, each recorded separately',
        memory='Linux child ru_maxrss in KiB, whole-process high-water mark including inherited interpreter/import memory; no baseline subtraction',
        decision_trace_policy='per-tuple decision trace suppressed equally in all methods; pruning trace, counters and complete arrays retained',
        tuple_prebudget=None,source_hashes={p.name:sha(p) for p in (RUN/'sources').glob('*.py')},
        public_hashes={p.name:sha(p) for p in (RUN/'public').glob('*.json')},
        reference_hashes={p.name:sha(p) for p in (RUN/'references').glob('*.json')},runner_sha256=sha(Path(__file__))))
    print('frozen',len(cases)*12,flush=True)

def child(conn,case,method,outpath):
    os.setsid()
    import sympy as s,ablation_core as core
    s.core.cache.clear_cache();conn.send('READY');tic=time.perf_counter()
    try:
        public=json.loads((RUN/'public'/(case+'.json')).read_text())
        out=core.decode(public,method);dump(outpath,out)
        conn.send(dict(outcome='complete' if out['complete'] else 'degenerate',seconds=time.perf_counter()-tic,
                       peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,status=out['status'],arrays=len(out['candidates']),
                       output_sha256=sha(outpath),tuple_product_before=out.get('tuple_product_before'),tuple_product_after=out.get('tuple_product_after')))
    except BaseException as exc:conn.send(dict(outcome='error',error=repr(exc),seconds=time.perf_counter()-tic))
    finally:conn.close()

def setup():
    assert os.name=='posix'
    sys.path.insert(0,str(ROOT/'tools/third_party/jsc_python_pure_1.14.0'))
    sys.path.insert(0,str(RUN/'sources'))
    os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{allowed[0]})
    tic=time.perf_counter();import sympy,ablation_core
    return dict(python=sys.version,sympy=sympy.__version__,platform=platform.platform(),affinity=sorted(os.sched_getaffinity(0)),
                cpu=next(line for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),
                common_import_seconds=time.perf_counter()-tic)

def smoke():
    runtime=setup();import ablation_core as core
    checks=[]
    for name in ['validation-01-flower-r2-k33','two_C6_N1_0','empty_r1']:
        public=json.loads((RUN/'public'/(name+'.json')).read_text());outputs=[]
        for method in METHODS:
            out=core.decode(public,method);outputs.append(out)
        expected={tuple(c['values']) for c in json.loads((RUN/'references'/(name+'.json')).read_text())['candidates']}
        assert all({tuple(c['values']) for c in out['candidates']}==expected for out in outputs)
        checks.append(dict(id=name,arrays=len(expected),all_four_match=True))
    dump(RUN/'smoke.json',dict(runtime=runtime,checks=checks,status='PASS'))
    print(json.dumps(checks),flush=True)

def run():
    protocol=json.loads((RUN/'protocol.json').read_text());assert not (RUN/'results.json').exists()
    assert sha(Path(__file__))==protocol['runner_sha256']
    for folder,key in [('sources','source_hashes'),('public','public_hashes'),('references','reference_hashes')]:
        assert all(sha(RUN/folder/name)==d for name,d in protocol[key].items())
    runtime=setup();dump(RUN/'runtime.json',runtime);ctx=mp.get_context('fork');records=[]
    for rep in range(3):
        for case in protocol['cases']:
            order=METHODS[rep:]+METHODS[:rep]
            for method in order:
                name=case['id'];output=RUN/'outputs'/f'{name}--{method}--{rep+1}.json'
                parent,conn=ctx.Pipe();proc=ctx.Process(target=child,args=(conn,name,method,output))
                record=dict(id=name,method=method,repeat=rep+1,load_before=Path('/proc/loadavg').read_text().strip())
                tic=time.perf_counter();proc.start();conn.close()
                if parent.poll(60) and parent.recv()=='READY':
                    record['child_startup_seconds']=time.perf_counter()-tic
                    if parent.poll(protocol['seconds_after_ready']):record.update(parent.recv())
                    else:
                        record.update(outcome='timeout',censor_seconds=protocol['seconds_after_ready'])
                        status=Path(f'/proc/{proc.pid}/status')
                        if status.exists():
                            for line in status.read_text().splitlines():
                                if line.startswith('VmHWM:'):record['peak_rss_kib']=int(line.split()[1])
                else:record.update(outcome='startup_error')
                if proc.is_alive() and record['outcome'] in ['timeout','startup_error']:os.killpg(proc.pid,signal.SIGKILL)
                proc.join(5);parent.close();records.append(record)
                dump(RUN/'results.json',dict(complete=len(records)==protocol['jobs'],protocol_sha256=sha(RUN/'protocol.json'),records=records))
                print(json.dumps(record),flush=True)

if __name__=='__main__':{'freeze':freeze,'smoke':smoke,'run':run}[sys.argv[1]]()
