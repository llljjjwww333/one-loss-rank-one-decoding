# Extended report for manuscript revision .17

The journal keeps the main mathematical argument and the essential supporting proofs.
This archive retains the expanded matched example, integer-lattice refinement,
separation-certificate coefficient heights, complete exact-check and experimental tables,
all per-input comparison and ablation results, and finite-grid protocols.
The PDF begins with a section-to-data map. Unprefixed references identify the article;
S-prefixed references identify its essential supplement; A-prefixed references are local.
The report sources include the contextual reference numbers and build independently.

The complete accompanying code and synthetic data are in the parent software archive.
Earlier scientific snapshot files, 192 ablation records, all 180 completed lists,
12 censored timeouts, fallback/empty/multiple controls and 72 pruning traces are retained.
Saved-output replay does not repeat benchmark timings. Reproduction commands and
precise Linux/WSL native-solver requirements remain in the repository README.
This archive does not publish the main journal manuscript, private reviews or author declarations.

Build the report by running source/build_report.ps1 with a LaTeX distribution.
The manifest lists SHA-256 hashes for every report/source member. The report and
source were checked by an independent extraction and clean rebuild before release.
