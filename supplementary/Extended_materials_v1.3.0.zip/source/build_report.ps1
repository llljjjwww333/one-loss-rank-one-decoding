$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    foreach ($i in 1..3) {
        & pdflatex -interaction=nonstopmode -halt-on-error extended_report.tex
        if ($LASTEXITCODE -ne 0) { throw 'Report LaTeX build failed.' }
        if ($i -eq 1) { & bibtex extended_report; if ($LASTEXITCODE -ne 0) { throw 'Report BibTeX failed.' } }
    }
} finally { Pop-Location }
