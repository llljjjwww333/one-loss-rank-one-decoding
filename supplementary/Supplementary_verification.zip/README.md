# Supplementary verification

These two standalone programs accompany the JSC manuscript. They do not import
the project's main decoder and need Python 3.11+ with SymPy 1.14.0.

```text
python -m pip install sympy==1.14.0
python check_theta_specialization.py
python minimal_two_cycles.py
```

The first checks the theta specialization for p=3,4,5,6, including all 112 false
points, exact equations, strict real-energy signs, true-point Jacobian ranks and
50-digit residuals. The second reproduces the two-six-cycle base point with nine
strictly bounded actual gradient candidates and complete-reply layer sizes 1/4/4.
Both regenerate their JSON receipts; the first also writes a small TeX table.

The finite checks corroborate the stated specializations. The general statements
are proved in the article. These checks repeat no solver benchmark timings.
