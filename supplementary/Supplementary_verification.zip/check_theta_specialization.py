"""Exact and 50-digit checks of the theta witness, p=3,4,5,6.

This checks the algebraic specialization, not the complete general theorem.
Run with Python 3.11 and SymPy 1.14.0; no project decoder is imported.
"""
from pathlib import Path
from itertools import combinations
import json
import sympy as s

HERE = Path(__file__).resolve().parent


def check():
    c, eps = s.symbols('c eps', real=True, positive=True)
    K = eps**2 + 2*eps
    re_b = (c-1)/(2*c)
    re_b2 = ((c-1)**2-2*c*K)/(2*c**2)
    assert s.simplify(re_b2+2*eps*re_b-((c-1)**2-2*c*eps*(eps+3-c))/(2*c**2)) == 0
    assert s.simplify(c*c*re_b2+2*c*re_b-(c*c-1-2*c*K)/2) == 0
    rows = []
    for p in [3, 4, 5, 6]:
        eps = s.Integer(p)
        K = eps**2+2*eps
        vectors = set()
        worst_outer = None
        worst_middle = None
        residual_max = s.Float(0, 50)
        for j in range(1, p//2+1):
            c = s.Rational(p-j, j)
            delta = (c-1)**2-4*c*K
            assert 1 <= c <= p-1 < eps and delta < 0
            for sign in [-1, 1]:
                beta = (c-1+sign*s.I*s.sqrt(-delta))/(2*c)
                alpha = -c*beta
                assert s.simplify(c*beta**2+(1-c)*beta+K) == 0
                assert s.simplify(j*alpha+(p-j)*beta) == 0
                for val in [alpha, beta]:
                    outer = s.simplify(s.re((1+val/eps)**2-1))
                    middle = s.simplify(s.re((1-val)**2-1))
                    assert outer < 0 and middle < 0
                    worst_outer = outer if worst_outer is None else max(worst_outer, outer)
                    worst_middle = middle if worst_middle is None else max(worst_middle, middle)
                for positions in combinations(range(p), j):
                    positions = set(positions)
                    vec = tuple(s.expand(alpha if i in positions else beta) for i in range(p))
                    vectors.add(vec)
        for vec in vectors:
            assert s.simplify(sum(vec)) == 0
            for i, j in combinations(range(p), 2):
                raw = (eps+vec[i])**2*(1-vec[j])-(eps+vec[j])**2*(1-vec[i])
                assert s.simplify(raw) == 0
                z = [v.evalf(50) for v in vec]
                numeric = abs(((eps+z[i])**2*(1-z[j])-(eps+z[j])**2*(1-z[i])).evalf(50))
                residual_max = max(residual_max, numeric)
        assert len(vectors) == 2**p-2
        variables = s.symbols(f't0:{p-1}')
        full = list(variables)+[-sum(variables)]
        equations = [(eps+full[i])**2*(1-full[-1])-(eps+full[-1])**2*(1-full[i]) for i in range(p-1)]
        jac = s.Matrix(equations).jacobian(variables).subs(dict.fromkeys(variables, 0))
        assert jac.rank() == p-1
        rows.append(dict(p=p, multiplicity_classes=p//2,
                         false_points=len(vectors), total_points=len(vectors)+1,
                         exact_equations_pass=True, true_jacobian_rank=jac.rank(),
                         largest_outer_relative_real_energy=str(worst_outer),
                         largest_middle_relative_real_energy=str(worst_middle),
                         numeric_precision_digits=50, numeric_residual_max=str(residual_max)))
    return dict(complete=True, sympy=s.__version__, rows=rows,
                scope='Finite specializations plus symbolic identities; not an independent proof of Theorem 2.2.')


if __name__ == '__main__':
    report = check()
    (HERE/'theta_specialization_checks.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    lines = [r'\section{Exact checks of the theta specialization}\label{supp:theta-check}',
             'For Lemma~\\ref{lem:normalization}, an independent SymPy 1.14.0 script',
             'enumerates the two-root multiplicity patterns for $p=3,4,5,6$.',
             'Every zero-sum and cycle equation is checked exactly, as are the four',
             'real-energy signs and the true-point Jacobian rank. A separate',
             '50-digit evaluation checks the equation residuals. Here each',
             'energy change is divided by the squared nonzero target edge.',
             r'Table~\ref{tab:theta-check} gives the exact energy maxima.',
             r'\begin{table}[ht]\centering\small\renewcommand{\arraystretch}{1.3}',
             r'\begin{tabular}{rrrrr}\toprule',
             r'$p$ & False points & Jacobian rank & Largest outer change & Largest middle change\\\midrule']
    for row in report['rows']:
        fmt=lambda k:str(s.sympify(row[k]))
        lines.append(f"{row['p']} & {row['false_points']} & {row['true_jacobian_rank']} & ${fmt('largest_outer_relative_real_energy')}$ & ${fmt('largest_middle_relative_real_energy')}$ " + r'\\')
    lines += [r'\bottomrule\end{tabular}',
              r'\caption{All specialized false points have strictly negative real energy change on every changed edge. The true point has zero change and is not included in the maxima.}\label{tab:theta-check}\end{table}',
              'The checks corroborate these finite specializations; the general',
              'argument for every $p$ is the proof in the article.',
              r'Run \texttt{python check\_theta\_specialization.py} from the revision folder.']
    table_dir = HERE/'manuscript' if (HERE/'manuscript').is_dir() else HERE
    (table_dir/'theta_specialization_checks.tex').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
