"""Reproduce the two-six-cycle base point of Corollary 3.1 exactly.

Run: python minimal_two_cycles.py
Dependency: sympy==1.14.0. No project decoder or downloaded data required.
"""
from itertools import product
from pathlib import Path
import json
import sympy as s


def run():
    r = 2
    lam = s.Rational(1, 256*r)
    q = s.Rational(1, 4*r)
    edges = []
    for k in range(r):
        a, b = 1+2*k, 2+2*k
        x, y, z = 3*k, 3*k+1, 3*k+2
        edges += [(0,x),(a,x),(a,y),(b,y),(b,z),(0,z)]
    m, n = 5, 6

    def reply(values):
        norm = s.simplify(sum(x*x for x in values))
        gu = [s.simplify(sum((q*q-values[e])*q for e,(ii,jj) in enumerate(edges) if ii == i)) for i in range(m)]
        gv = [s.simplify(sum((q*q-values[e])*q for e,(ii,jj) in enumerate(edges) if jj == j)) for j in range(n)]
        loss = s.simplify(sum((q*q-x)**2 for x in values)/2)
        return norm, gu, gv, loss

    arrays = []
    for roots in product([s.Integer(0),s.sqrt(3),-s.sqrt(3)], repeat=r):
        a = [s.Integer(1)]
        b = []
        values = []
        for t in roots:
            values += [lam*x for x in [1+t,1-t,1+t,1-t,-2+t,-2-t]]
            if t == 0:
                a += [s.Integer(1),s.Integer(1)]
                b += [s.Integer(1),s.Integer(1),-s.Integer(2)]
            else:
                a += [t-2,7-4*t]
                b += [1+t,-5-3*t,-2-t]
        for e,(i,j) in enumerate(edges):
            assert s.simplify(lam*a[i]*b[j]-values[e]) == 0
        assert s.simplify(lam*sum(x*x for x in a)) < 1
        assert s.simplify(lam*sum(x*x for x in b)) < 1
        arrays.append((values,reply(values)))
    reference = arrays[0][1]
    for _,rep in arrays:
        assert rep[1:3] == reference[1:3]
    counts = {}
    for _,rep in arrays:
        counts[str(rep[0])] = counts.get(str(rep[0]),0)+1
    assert sorted(counts.values()) == [1,4,4]
    unique = sum(rep[3] == reference[3] for _,rep in arrays)
    assert unique == 1
    assert m*q*q < 1 and n*q*q < 1
    # The observed-edge binomial is 2 lambda^3 t(t^2-3), with three simple roots.
    t = s.symbols('t')
    binomial = s.expand((1+t)**2*(-2+t)-(1-t)**2*(-2-t))
    assert s.expand(binomial-2*t*(t*t-3)) == 0
    assert s.Poly(s.gcd(binomial,s.diff(binomial,t)),t).degree() == 0
    result = dict(complete=True, cycles=2, gradient_candidates=9,
                  all_candidates_actual_and_strictly_bounded=True,
                  complete_reply_layer_sizes=sorted(counts.values()),
                  base_target_complete_reply_candidates=unique,
                  cycle_polynomial=str(binomial),
                  scope='Exact base point and simple roots used by Corollary 3.1; no new sampled cohort.')
    return result


if __name__ == '__main__':
    result = run()
    Path(__file__).with_name('minimal_two_cycles_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
